package com.jspider.constructor;

import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Component;

@Component

public class DragonProcessor2 implements MobileProcessor {

	@Override
	public void process() {
		System.out.println("worlds best processor ..........");

	}

}
