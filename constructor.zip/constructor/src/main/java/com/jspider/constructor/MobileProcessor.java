package com.jspider.constructor;

public interface MobileProcessor {
	
	void process();

}
