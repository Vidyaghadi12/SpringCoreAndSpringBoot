package com.jspider.constructor;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestStudent {

	public static void main(String[] args)
	{
		
//		Samsung sm = new Samsung();
//		sm.config();
		
		ApplicationContext appContext = new AnnotationConfigApplicationContext(AppConfig.class);
		Samsung s7 = appContext.getBean(Samsung.class);
		s7.config();
		
//		ClassPathXmlApplicationContext contex =new 
//				ClassPathXmlApplicationContext("com/jspider/constructor/constructor_injection.xml");
//        Student s1=(Student) contex.getBean("Vidya");
//		System.out.println(s1);
	}

}
