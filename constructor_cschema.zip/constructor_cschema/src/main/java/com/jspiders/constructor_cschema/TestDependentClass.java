package com.jspiders.constructor_cschema;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestDependentClass {

	public static void main(String[] args) 
	{
//	    Employee emp = new Employee();
//		emp.empsal();
//		
//		Recruiter rec = new Recruiter();
//		rec.jobs();
		
//		ClassPathXmlApplicationContext con=new
//				ClassPathXmlApplicationContext("com/jspiders/constructor_cschema/Constructor_cschema.xml");
		// TODO Auto-generated method stub
//		Student ss=(Student)con.getBean("Vidya");
//		Employee emp = (Employee) con.getBean("emp");
//		Recruiter rec1 = (Recruiter) con.getBean("rec");
//		Recruiter rec2 = (Recruiter) con.getBean("rec3");
//		emp.empsal();
//		rec1.jobs();
//		rec2.empsal();
//		System.out.println(emp);
//		IT obj = new Recruiter();
//		obj.jobs();
	  ApplicationContext conn = new ClassPathXmlApplicationContext("com/jspiders/constructor_cschema/Constructor_cschema.xml"); 
       IT it = (IT) conn.getBean("recruiter");
       it.jobs();
       
       Student std= (Student) conn.getBean("student");
       System.out.println(std);
//       std.setId(23);
//       std.setMarks(23);
//       std.setName("Vidya");
//       System.out.println(std);
	}
	
//	xmlns:context="http://www.springframework.org/schema/context"
//			xmlns:p="http://www.springframework.org/schema/p"
//			xmlns:c="http://www.springframework.org/schema/c"
//			
//			c:id="113" c:name="Asmita Patil" c:marks="80"

}
