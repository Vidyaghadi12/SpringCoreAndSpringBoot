package com.jspiders.constructor_cschema;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Recruiter implements IT{
	
	@Autowired
	private Student student;
	
	/**
	 * @return the recruiter
	 */
	public Student getStudent() {
		return student;
	}

	/**
	 * @param recruiter the recruiter to set
	 */
	public void setStudent(Student student) {
		this.student = student;
	}

	public void jobs() {
		System.out.println("printing new jobs........." +student);
	}

}
