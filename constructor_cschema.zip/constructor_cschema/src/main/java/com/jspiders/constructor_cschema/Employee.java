package com.jspiders.constructor_cschema;

import org.springframework.stereotype.Component;

@Component
public class Employee implements IT{
	public void jobs() {
		System.out.println("printing salary");
	}
	}
