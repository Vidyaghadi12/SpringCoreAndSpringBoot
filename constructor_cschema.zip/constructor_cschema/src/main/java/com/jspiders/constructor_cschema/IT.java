package com.jspiders.constructor_cschema;

public interface IT {
	 void jobs();
}
