package com.jspiders.constructor_injection2;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ListTypeTest {

	public static void main(String[] args)
	{
		
	  ClassPathXmlApplicationContext contex = new 
			  ClassPathXmlApplicationContext("com/jspiders/constructor_injection2/ListTypeInjection.xml");
	  ListTypeInjection  s1=(ListTypeInjection) contex.getBean("Vidya");
	  System.out.println(s1);

	}

}
